import { useScrollFade } from "@/hooks/useScrollFade";

const certifications = [
  { title: "MumbaiHacks 2025 Finalist", emoji: "🏆", org: "MumbaiHacks" },
  { title: "Data Science Essentials with Python", emoji: "🐍", org: "Cisco Networking Academy", certId: "81213f2e-747e-4cef-8e79-bbee03cce466", isNew: true },
  { title: "MATLAB Onramp Certificate", emoji: "📊", org: "MathWorks" },
  { title: "MLOps for Generative AI", emoji: "☁️", org: "Google Cloud" },
  { title: "Introduction to Generative AI", emoji: "🤖", org: "Google Cloud" },
  
  { title: "EDC IIT Delhi Campus Ambassador", emoji: "🎓", org: "IIT Delhi" },
];

const CertificationsSection = () => {
  const ref = useScrollFade<HTMLElement>();

  return (
    <section id="certifications" ref={ref} className="scroll-fade max-w-[1200px] mx-auto px-8 py-16">
      <h2 className="font-heading text-sm uppercase tracking-[0.2em] text-ink mb-10 font-bold">Certifications</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {certifications.map((cert, i) => (
          <div key={i} className="cert-card bg-card-surface p-5 cursor-default relative" style={{ border: `1.5px solid ${cert.isNew ? 'hsl(var(--teal))' : 'hsl(var(--ink))'}` }}>
            {cert.isNew && (
              <span className="absolute top-0 right-0 bg-teal text-cream font-mono uppercase tracking-[0.1em] px-[0.6rem] py-[0.2rem]" style={{ fontSize: '0.55rem' }}>
                New · Apr 2026
              </span>
            )}
            <span className="text-2xl mb-3 block">{cert.emoji}</span>
            <h3 className="font-display text-base text-ink mb-1">{cert.title}</h3>
            <p className="font-mono text-[0.65rem] text-muted-brand uppercase tracking-wider">{cert.org}</p>
            {cert.certId && (
              <p className="font-mono text-[0.6rem] text-muted-brand mt-1">ID: {cert.certId}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};

export default CertificationsSection;
