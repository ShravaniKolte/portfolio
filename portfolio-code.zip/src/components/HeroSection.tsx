import { useScrollFade } from "@/hooks/useScrollFade";

const metaBlocks = [
  { label: "College", value: "Zeal College of Engineering & Research" },
  { label: "Degree", value: "B.Tech Robotics & Automation" },
  { label: "CGPA", value: "8.0 / 10" },
  { label: "Location", value: "Pune, Maharashtra, India" },
  { label: "Contact", value: "shravanikolte2103@gmail.com · 9975822421" },
];

const HeroSection = () => {
  const ref = useScrollFade<HTMLElement>();

  return (
    <section id="about" ref={ref} className="scroll-fade max-w-[1200px] mx-auto px-8 py-16">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-0">
        <div className="pr-0 lg:pr-12">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-7 h-[2px] bg-rust" />
            <span className="font-mono text-xs uppercase tracking-wider text-rust">
              B.Tech Robotics & Automation · Pune, India
            </span>
          </div>
          <h1 className="font-display leading-[0.95] mb-6" style={{ fontSize: 'clamp(3rem, 6vw, 5.2rem)' }}>
            Shravani{" "}
            <em className="text-teal not-italic" style={{ fontStyle: 'italic' }}>Kolte</em>
          </h1>
          <p className="font-heading text-sm uppercase tracking-[0.2em] text-muted-brand mb-6 font-bold">
            Data Analytics · CAD · Product · AI
          </p>
          <p className="font-mono text-sm text-muted-brand leading-relaxed mb-8 max-w-[540px]">
            A multidisciplinary engineering student driven by the intersection of data analytics,
            computer-aided design, and artificial intelligence. Passionate about building products
            that merge hardware thinking with data-driven insight.
          </p>
          <div className="flex flex-wrap gap-3">
            <a href="https://github.com/ShravaniKolte/" target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-rust text-cream font-mono text-xs uppercase tracking-wider hover:opacity-90 transition-opacity"
              style={{ border: '1.5px solid hsl(var(--ink))' }}>GitHub</a>
            <a href="https://www.linkedin.com/in/shravani-kolte-a5418a381" target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-transparent text-ink font-mono text-xs uppercase tracking-wider hover-sand transition-colors"
              style={{ border: '1.5px solid hsl(var(--ink))' }}>LinkedIn</a>
            <a href="https://profile-weaver--shravanikolte21.replit.app" target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-transparent text-ink font-mono text-xs uppercase tracking-wider hover-sand transition-colors"
              style={{ border: '1.5px solid hsl(var(--ink))' }}>Live Site</a>
          </div>
        </div>
        <div className="mt-10 lg:mt-0 pt-10 lg:pt-0 lg:pl-8"
          style={{ borderLeft: 'none', borderTop: '1.5px solid hsl(var(--ink))' }}>
          <style>{`@media (min-width: 1024px) { .sidebar-border { border-left: 1.5px solid hsl(var(--ink)) !important; border-top: none !important; } }`}</style>
          <div className="sidebar-border lg:pl-8 space-y-5" style={{ borderLeft: 'none', borderTop: 'none' }}>
            {metaBlocks.map((block) => (
              <div key={block.label}>
                <span className="font-mono text-[0.65rem] uppercase tracking-[0.15em] text-rust font-medium">{block.label}</span>
                <p className="font-mono text-sm text-ink mt-0.5">{block.value}</p>
              </div>
            ))}
            <div className="flex items-center gap-2 px-3 py-2 bg-teal/10 mt-4" style={{ border: '1.5px solid hsl(var(--teal))' }}>
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500" />
              </span>
              <span className="font-mono text-xs text-teal uppercase tracking-wider">Open to Opportunities</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
