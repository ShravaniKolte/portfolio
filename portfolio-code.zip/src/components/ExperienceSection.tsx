import { useScrollFade } from "@/hooks/useScrollFade";

const experiences = [
  { date: "Jan – Feb 2026", company: "Tantarata Solutions", role: "AI & Web Tech Intern", type: "Internship" as const, description: "Worked on AI integration and web development projects, gaining hands-on experience with modern tech stacks." },
  { date: "Jun – Jul 2025", company: "Sun Fibo Technology", role: "CAD Application Engineer Intern", type: "Internship" as const, description: "Applied CAD workflows using Siemens NX and AutoCAD for engineering design and documentation." },
  { date: "Jan 2026", company: "Siemens Mobility — Forage", role: "Project Manager Simulation", type: "Externship" as const, description: "Completed a virtual externship simulating project management workflows in mobility engineering." },
  { date: "Jun 2025", company: "Tata iQ — Forage", role: "Data Analytics Simulation", type: "Externship" as const, description: "Performed data analytics tasks including data cleaning, visualization, and business insight generation." },
  { date: "Mar 2025", company: "TCS — Forage", role: "Data Visualisation Simulation", type: "Externship" as const, description: "Created data visualizations and dashboards to communicate business metrics effectively." },
];

const ExperienceSection = () => {
  const ref = useScrollFade<HTMLElement>();

  return (
    <section id="experience" ref={ref} className="scroll-fade max-w-[1200px] mx-auto px-8 py-16">
      <h2 className="font-heading text-sm uppercase tracking-[0.2em] text-ink mb-10 font-bold">Experience</h2>
      <div className="space-y-0">
        {experiences.map((exp, i) => (
          <div key={i} className="grid grid-cols-1 md:grid-cols-[160px_1fr] gap-4 md:gap-8 py-6 hover-sand transition-colors"
            style={{ borderTop: '1.5px solid hsl(var(--ink))' }}>
            <span className="font-mono text-xs text-muted-brand uppercase tracking-wider pt-1">{exp.date}</span>
            <div>
              <div className="flex flex-wrap items-center gap-3 mb-1">
                <h3 className="font-display text-lg text-ink">{exp.company}</h3>
                <span className={`font-mono text-[0.6rem] uppercase tracking-wider px-2 py-0.5 ${exp.type === "Internship" ? "bg-rust text-cream" : "bg-teal text-cream"}`}>{exp.type}</span>
              </div>
              <p className="font-heading text-sm font-bold text-ink mb-1">{exp.role}</p>
              <p className="font-mono text-xs text-muted-brand leading-relaxed">{exp.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ExperienceSection;
