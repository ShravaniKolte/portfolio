import { Link } from "react-router-dom";
import { useScrollFade } from "@/hooks/useScrollFade";

const phases = [
  { name: "Phase 1 Data Collection", status: "done", color: "bg-teal" },
  { name: "Phase 2 Data Cleaning", status: "done", color: "bg-teal" },
  { name: "Phase 3 Deep-Dive EDA", status: "active", color: "bg-rust" },
  { name: "Phase 4 Model Building", status: "upcoming", color: "" },
  { name: "Phase 5 Dashboard + Report", status: "upcoming", color: "" },
];

const classifications = [
  { label: "Future-Proof", color: "bg-green-500" },
  { label: "Stable", color: "bg-teal" },
  { label: "At-Risk", color: "bg-gold" },
  { label: "Likely Obsolete", color: "bg-rust" },
];

const featuredTech = [
  "Python", "Pandas", "NumPy", "Scikit-learn", "Matplotlib",
  "Seaborn", "Power BI", "EDA", "Machine Learning", "Labor Economics",
];

const smallProjects = [
  {
    title: "Soil Moisture Monitoring System",
    tag: "Hardware",
    date: "Apr – May 2025",
    tech: ["Arduino IDE", "TinkerCAD"],
    description: "IoT-based system to monitor soil moisture levels for agricultural applications.",
  },
  {
    title: "Currency Detector System",
    tag: "Hardware",
    date: "Feb – Mar 2025",
    tech: ["Arduino IDE", "TinkerCAD", "Color Sensor"],
    description: "Hardware project using color sensors to detect and classify currency denominations.",
  },
];

const ProjectsSection = () => {
  const ref = useScrollFade<HTMLElement>();

  return (
    <section id="projects" ref={ref} className="scroll-fade max-w-[1200px] mx-auto px-8 py-16">
      <h2 className="font-heading text-sm uppercase tracking-[0.2em] text-ink mb-10 font-bold">Projects</h2>

      {/* Featured Card */}
      <Link
        to="/project/skill-survival"
        className="block bg-ink text-cream p-8 md:p-10 mb-6 hover:opacity-95 transition-opacity"
        style={{ border: '1.5px solid hsl(var(--ink))' }}
      >
        <span className="font-mono text-[0.65rem] uppercase tracking-[0.15em] text-rust mb-3 block">
          Featured Research
        </span>
        <h3 className="font-display text-2xl md:text-3xl mb-4 italic">
          Predicting Skill Survival in AI-Driven Labor Markets 2010–2030
        </h3>
        <p className="font-mono text-sm text-cream/70 leading-relaxed mb-8 max-w-[700px]">
          A comprehensive research project analyzing how artificial intelligence is reshaping the labor market,
          predicting which skills will remain relevant, become obsolete, or emerge as critical in the next decade.
        </p>

        {/* Progress Phases */}
        <div className="flex flex-wrap gap-0 mb-8">
          {phases.map((phase, i) => (
            <div
              key={i}
              className={`font-mono text-[0.6rem] uppercase tracking-wider px-3 py-2 ${
                phase.status === "upcoming" ? "text-cream/30" : `${phase.color} text-cream`
              }`}
              style={{ border: '1.5px solid hsl(var(--cream) / 0.2)' }}
            >
              {phase.name}
              <span className="ml-2">
                {phase.status === "done" ? "✓ Done" : phase.status === "active" ? "→ Active" : "Upcoming"}
              </span>
            </div>
          ))}
        </div>

        {/* Classification Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          {classifications.map((c) => (
            <div key={c.label} className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${c.color}`} />
              <span className="font-mono text-xs text-cream/70">{c.label}</span>
            </div>
          ))}
        </div>

        {/* Tech Chips */}
        <div className="flex flex-wrap gap-2">
          {featuredTech.map((t) => (
            <span
              key={t}
              className="font-mono text-[0.6rem] uppercase tracking-wider px-2.5 py-1 text-cream/80"
              style={{ border: '1.5px solid hsl(var(--cream) / 0.2)' }}
            >
              {t}
            </span>
          ))}
        </div>
      </Link>

      {/* Featured Card — Quantum Advantage */}
      <Link
        to="/project/quantum-advantage"
        className="block bg-cream text-ink p-8 md:p-10 mb-6 hover:opacity-95 transition-opacity relative"
        style={{ border: '1.5px solid hsl(var(--ink))' }}
      >
        <span className="absolute top-0 right-0 bg-gold text-ink font-mono uppercase tracking-[0.1em] px-3 py-1" style={{ fontSize: '0.6rem' }}>
          🏆 Won · Avishkar '26
        </span>
        <span className="font-mono text-[0.65rem] uppercase tracking-[0.15em] text-rust mb-3 block">
          Featured Research · IEEE Paper
        </span>
        <h3 className="font-display text-2xl md:text-3xl mb-4 italic">
          Forecasting Quantum Advantage in Global Trends & India's Readiness
        </h3>
        <p className="font-mono text-sm text-muted-brand leading-relaxed mb-6 max-w-[700px]">
          A data-driven IEEE research paper analyzing global quantum computing trends using IBM qubit data,
          100K NISQ circuit records, and country-wise investment comparison. Applies ARIMA forecasting to
          predict the quantum advantage timeline (2026–2028) and assesses India's readiness under the NQM.
        </p>
        <div className="flex flex-wrap gap-2">
          {["Quantum Computing", "ARIMA", "Python", "Power BI", "IEEE Paper", "Data Analytics"].map((t) => (
            <span
              key={t}
              className="font-mono text-[0.6rem] uppercase tracking-wider px-2.5 py-1 text-ink"
              style={{ border: '1.5px solid hsl(var(--ink))' }}
            >
              {t}
            </span>
          ))}
        </div>
        <div className="mt-6 font-mono text-[0.7rem] uppercase tracking-[0.12em] text-rust">
          → View Project
        </div>
      </Link>

      {/* Small Project Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {smallProjects.map((project, i) => (
          <div
            key={i}
            className="bg-card-surface p-6 hover-sand transition-colors"
            style={{ border: '1.5px solid hsl(var(--ink))' }}
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="font-mono text-[0.6rem] uppercase tracking-wider px-2 py-0.5 bg-ink text-cream">
                {project.tag}
              </span>
              <span className="font-mono text-[0.65rem] text-muted-brand">{project.date}</span>
            </div>
            <h3 className="font-display text-lg text-ink mb-2">{project.title}</h3>
            <p className="font-mono text-xs text-muted-brand leading-relaxed mb-4">{project.description}</p>
            <div className="flex flex-wrap gap-2">
              {project.tech.map((t) => (
                <span
                  key={t}
                  className="font-mono text-[0.6rem] uppercase tracking-wider px-2 py-0.5 text-ink"
                  style={{ border: '1.5px solid hsl(var(--ink))' }}
                >
                  {t}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProjectsSection;
