const Footer = () => (
  <footer
    className="max-w-[1200px] mx-auto px-8 py-8"
    style={{ borderTop: '1.5px solid hsl(var(--ink))' }}
  >
    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
      <p className="font-display text-lg italic text-ink">Shravani Kolte</p>
      <p className="font-mono text-xs text-muted-brand text-center">
        Pune, Maharashtra · Open to Remote & On-site
      </p>
      <div className="flex gap-4">
        {[
          { label: "GitHub", href: "https://github.com/ShravaniKolte" },
          { label: "LinkedIn", href: "https://www.linkedin.com/in/shravani-kolte-a5418a381" },
          { label: "Email", href: "mailto:shravanikolte2103@gmail.com" },
          { label: "Phone", href: "tel:9975822421" },
          { label: "Live Site", href: "https://profile-weaver--shravanikolte21.replit.app" },
        ].map((link) => (
          <a
            key={link.label}
            href={link.href}
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-[0.65rem] uppercase tracking-wider text-muted-brand hover:text-rust transition-colors"
          >
            {link.label}
          </a>
        ))}
      </div>
    </div>
  </footer>
);

export default Footer;
