const navLinks = [
  { label: "About", href: "#about" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Achievements", href: "#achievements" },
  { label: "Certifications", href: "#certifications" },
  { label: "Skills", href: "#skills" },
];

const StickyHeader = () => (
  <header className="sticky top-0 z-50 backdrop-blur-md bg-cream/80 border-b border-ink" style={{ borderWidth: '1.5px' }}>
    <div className="max-w-[1200px] mx-auto px-8 py-4 flex items-center justify-between">
      <a href="#" className="font-heading text-xl font-bold uppercase text-ink tracking-tight">
        SK<span className="text-rust">.</span>
      </a>
      <nav className="hidden md:flex gap-6">
        {navLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className="font-mono text-[0.7rem] uppercase text-muted-brand hover:text-rust transition-colors tracking-wider"
          >
            {link.label}
          </a>
        ))}
      </nav>
    </div>
  </header>
);

export default StickyHeader;
