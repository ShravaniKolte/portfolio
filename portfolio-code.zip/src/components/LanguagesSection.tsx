import { useScrollFade } from "@/hooks/useScrollFade";

const languages = [
  { name: "English", level: "Professional" },
  { name: "हिंदी", level: "Professional Working" },
  { name: "मराठी", level: "Native" },
  { name: "Deutsch", level: "Elementary" },
];

const LanguagesSection = () => {
  const ref = useScrollFade<HTMLElement>();

  return (
    <section ref={ref} className="scroll-fade max-w-[1200px] mx-auto px-8 py-16">
      <h2 className="font-heading text-sm uppercase tracking-[0.2em] text-ink mb-10 font-bold">Languages</h2>
      <div className="flex flex-wrap justify-center gap-4">
        {languages.map((lang, i) => (
          <div key={i} className="bg-card-surface px-8 py-5 text-center hover-sand transition-colors min-w-[160px]" style={{ border: '1.5px solid hsl(var(--ink))' }}>
            <p className="font-display text-xl italic text-ink mb-1">{lang.name}</p>
            <p className="font-mono text-[0.65rem] uppercase tracking-wider text-muted-brand">{lang.level}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default LanguagesSection;
