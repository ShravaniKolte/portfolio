import { useScrollFade } from "@/hooks/useScrollFade";

const skillGroups = [
  { label: "Data & Analytics", chipColor: "bg-teal/10 text-teal", skills: ["Python","Power BI","Data Analytics","Data Science","SQL","EDA","Machine Learning","MATLAB","MS Excel"] },
  { label: "Engineering & Design", chipColor: "bg-rust/10 text-rust", skills: ["AutoCAD","Siemens NX","TinkerCAD","Arduino IDE","CAD Workflows","Canva"] },
  { label: "Programming & Tech", chipColor: "bg-ink/5 text-ink", skills: ["C / C++","Java","Python","HTML","Full-Stack Basics (AI-Assisted)"] },
  { label: "AI & Emerging Tech", chipColor: "bg-gold/10 text-gold", skills: ["Generative AI with AI Tools"] },
  { label: "Soft Skills", chipColor: "bg-ink/5 text-ink", skills: ["Communication","Team Collaboration","Problem Solving","Adaptability","Project Management"] },
];

const SkillsSection = () => {
  const ref = useScrollFade<HTMLElement>();

  return (
    <section id="skills" ref={ref} className="scroll-fade max-w-[1200px] mx-auto px-8 py-16">
      <h2 className="font-heading text-sm uppercase tracking-[0.2em] text-ink mb-10 font-bold">Skills</h2>
      <div className="space-y-8">
        {skillGroups.map((group, i) => (
          <div key={i}>
            <span className="font-mono text-[0.65rem] uppercase tracking-[0.15em] text-rust font-medium mb-3 block">{group.label}</span>
            <div className="flex flex-wrap gap-2">
              {group.skills.map((skill) => (
                <span key={skill} className={`font-mono text-xs px-3 py-1.5 ${group.chipColor}`} style={{ border: '1.5px solid currentColor' }}>{skill}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default SkillsSection;
