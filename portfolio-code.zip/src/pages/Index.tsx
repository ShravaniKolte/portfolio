import StickyHeader from "@/components/StickyHeader";
import HeroSection from "@/components/HeroSection";
import ExperienceSection from "@/components/ExperienceSection";
import ProjectsSection from "@/components/ProjectsSection";
import CertificationsSection from "@/components/CertificationsSection";
import SkillsSection from "@/components/SkillsSection";
import LanguagesSection from "@/components/LanguagesSection";
import Footer from "@/components/Footer";

const Index = () => (
  <div className="min-h-screen">
    <StickyHeader />
    <HeroSection />
    <hr className="section-divider" />
    <ExperienceSection />
    <hr className="section-divider" />
    <ProjectsSection />
    <hr className="section-divider" />
    <CertificationsSection />
    <hr className="section-divider" />
    <SkillsSection />
    <hr className="section-divider" />
    <LanguagesSection />
    <hr className="section-divider" />
    <Footer />
  </div>
);

export default Index;
