import { Link } from "react-router-dom";

const phases = [
  { num: "01", name: "Data Collection", desc: "Sourced ai_impact_jobs_2010_2025.csv covering global job and skill trend data across 15 years.", status: "done" },
  { num: "02", name: "Data Cleaning", desc: "Produced cleaned_skill_data.csv — handled nulls, standardized formats, removed duplicates.", status: "done" },
  { num: "03", name: "Deep-Dive EDA", desc: "Uncovering trends in skill demand shifts, sector-level automation impact, and temporal patterns.", status: "active" },
  { num: "04", name: "Model Building", desc: "Building Skill Survival Probability classifier using ML — labeling skills as future-proof, stable, at-risk, or obsolete.", status: "upcoming" },
  { num: "05", name: "Dashboard + Report", desc: "Interactive Power BI dashboard and final comprehensive research report.", status: "upcoming" },
];

const classificationRows = [
  { dot: "bg-[#2d8a5e]", category: "Future-Proof", definition: "Skills with rising demand even post-2025", characteristics: "High creativity, judgment, interpersonal depth", examples: "AI Prompt Engineering, Strategic Leadership" },
  { dot: "bg-teal", category: "Stable", definition: "Steady demand, low automation risk", characteristics: "Complementary to AI systems", examples: "Python, Critical Thinking, Project Management" },
  { dot: "bg-gold", category: "At-Risk", definition: "Declining demand, partial automation possible", characteristics: "Routine, rule-based, moderate complexity", examples: "Basic Data Entry, Manual Reporting" },
  { dot: "bg-rust", category: "Likely Obsolete", definition: "Strong downward trend, high substitution probability", characteristics: "Fully automatable, low cognitive demand", examples: "Manual Invoice Processing, Switchboard Operation" },
];

const skills = [
  { icon: "🐍", name: "Python", detail: "Pandas, NumPy, Scikit-learn for data processing and ML modeling" },
  { icon: "📊", name: "Power BI", detail: "Interactive dashboard for visualizing skill survival trends and predictions" },
  { icon: "🔍", name: "EDA", detail: "Matplotlib, Seaborn for exploratory visualization and pattern discovery" },
  { icon: "🤖", name: "Machine Learning", detail: "Classification model to compute Skill Survival Probability scores" },
];

const outcomes = [
  { title: "Skill Survival Probability Model", text: "A trained ML classifier that assigns each skill a survival probability score and a label — future-proof, stable, at-risk, or obsolete — based on historical demand patterns." },
  { title: "Power BI Dashboard", text: "An interactive dashboard showing sector-wise skill obsolescence rates, temporal demand shifts, and 2030 forecasts — designed for HR professionals, researchers, and career planners." },
  { title: "Trend Analysis (2010–2025)", text: "Deep-dive EDA uncovering which sectors and skill types were most disrupted by AI adoption, and the inflection points at which demand shifted." },
  { title: "Research Report", text: "A comprehensive written report documenting methodology, findings, model performance, and actionable recommendations for future workforce planning and skill development." },
];

const tags = [
  { label: "Python", color: "text-rust" },
  { label: "Power BI", color: "text-teal" },
  { label: "Machine Learning", color: "text-gold" },
  { label: "Data Cleaning", color: "text-ink" },
  { label: "EDA", color: "text-rust" },
  { label: "Labor Economics", color: "text-teal" },
];

const SkillSurvivalProject = () => (
  <div className="min-h-screen">
    {/* Header */}
    <header className="px-8 md:px-16 pt-10 pb-6 flex justify-between items-start animate-fade-down" style={{ borderBottom: '1.5px solid hsl(var(--ink))' }}>
      <Link to="/" className="font-heading text-[1.05rem] font-[800] uppercase tracking-[0.02em] text-ink">
        Shravani<span className="text-rust">.</span>Portfolio
      </Link>
      <nav className="hidden md:flex gap-8 items-center">
        <Link to="/" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Home</Link>
        <Link to="/#projects" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Projects</Link>
        <Link to="/#achievements" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Achievements</Link>
        <Link to="/#skills" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Skills</Link>
        <Link to="/#certifications" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Contact</Link>
      </nav>
    </header>

    {/* Hero */}
    <section className="px-8 md:px-16 py-12 md:py-20 grid grid-cols-1 md:grid-cols-[1fr_380px] gap-8 md:gap-16 items-start animate-fade-up">
      <div>
        <div className="flex items-center gap-2.5 mb-5">
          <span className="inline-block w-6 h-[1.5px] bg-rust" />
          <span className="font-mono text-[0.68rem] uppercase tracking-[0.18em] text-rust">Data Analytics · Machine Learning · 2025</span>
        </div>
        <h1 className="font-display font-medium leading-[1.1] tracking-[-0.02em] mb-7" style={{ fontSize: 'clamp(2.4rem, 5vw, 4rem)' }}>
          Predicting<br /><em className="italic text-teal">Skill Survival</em><br />in AI-Driven<br />Labor Markets
        </h1>
        <p className="font-mono text-[0.88rem] text-muted-brand leading-[1.9] max-w-[520px] mb-10">
          A data-driven investigation into which human skills will survive automation. Analyzing global employment trends from 2010–2025, this project builds a Skill Survival Probability model that classifies every skill into one of four futures.
        </p>
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t.label} className={`font-mono text-[0.68rem] uppercase tracking-[0.1em] px-3.5 py-1 ${t.color}`} style={{ border: '1px solid currentColor', borderRadius: '2px' }}>
              {t.label}
            </span>
          ))}
        </div>
      </div>
      <div className="md:border-l md:border-ink md:pl-8 border-t md:border-t-0 border-ink pt-6 md:pt-2 flex flex-col gap-7" style={{ borderWidth: '1.5px' }}>
        {[
          { label: "Project Type", value: "Research · Analytics" },
          { label: "Duration", value: "2025 (Ongoing)" },
          { label: "Data Period", value: "2010 – 2030" },
          { label: "Role", value: "Solo Researcher & Developer" },
        ].map((m) => (
          <div key={m.label}>
            <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-muted-brand mb-1">{m.label}</div>
            <div className="font-heading font-semibold text-[0.88rem]">{m.value}</div>
          </div>
        ))}
        <div>
          <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-muted-brand mb-1">Status</div>
          <div className="inline-flex items-center gap-1.5 font-mono text-[0.72rem]">
            <span className="w-[7px] h-[7px] rounded-full bg-gold animate-pulse-dot" />
            In Progress — EDA Phase
          </div>
        </div>
      </div>
    </section>

    <div className="section-divider" />

    {/* Project Phases */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">01</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Project Phases</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5" style={{ border: '1.5px solid hsl(var(--ink))' }}>
        {phases.map((p, i) => (
          <div key={i} className="p-6 hover-sand transition-colors relative" style={{ borderRight: i < 4 ? '1.5px solid hsl(var(--ink))' : 'none' }}>
            <div className={`font-display text-[2.5rem] font-light leading-none mb-3 ${p.status === 'done' ? 'text-teal/35' : p.status === 'active' ? 'text-rust/50' : 'text-sand'}`}>
              {p.num}
            </div>
            <div className="font-heading font-bold text-[0.78rem] uppercase tracking-[0.05em] mb-2">{p.name}</div>
            <div className="font-mono text-[0.72rem] text-muted-brand leading-relaxed">{p.desc}</div>
            <span className={`mt-4 inline-block font-mono text-[0.6rem] uppercase tracking-[0.12em] px-2.5 py-1 rounded-sm ${
              p.status === 'done' ? 'bg-teal text-cream' : p.status === 'active' ? 'bg-rust text-cream' : 'bg-sand text-muted-brand border border-muted-brand'
            }`}>
              {p.status === 'done' ? '✓ Complete' : p.status === 'active' ? '→ In Progress' : 'Upcoming'}
            </span>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Classification Table */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">02</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Skill Classification System</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[0.78rem] border-collapse">
          <thead>
            <tr>
              {["Category", "Definition", "Characteristics", "Examples"].map((h) => (
                <th key={h} className="font-heading font-bold text-[0.68rem] uppercase tracking-[0.1em] text-left px-5 py-3.5 bg-ink text-cream">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {classificationRows.map((r) => (
              <tr key={r.category} className="hover-sand transition-colors">
                <td className="px-5 py-3.5 border-b border-sand font-mono"><span className={`inline-block w-2 h-2 rounded-full ${r.dot} mr-2`} />{r.category}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.definition}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.characteristics}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.examples}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>

    <div className="section-divider" />

    {/* Dataset Overview */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">03</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Dataset Overview</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-3 bg-ink text-cream p-6" style={{ border: '1.5px solid hsl(var(--ink))' }}>
          <div className="font-heading font-[800] text-[1rem] mb-2">ai_impact_jobs_2010_2025.csv → cleaned_skill_data.csv</div>
          <div className="font-mono text-[0.75rem] opacity-70">Raw global employment and skill-demand data cleaned into a structured analytical dataset ready for EDA and modeling.</div>
        </div>
        {[
          { num: "15", label: "Years of Data" },
          { num: "2010", label: "Start Year" },
          { num: "4", label: "Skill Categories" },
        ].map((d) => (
          <div key={d.label} className="bg-card-surface p-6" style={{ border: '1.5px solid hsl(var(--ink))' }}>
            <div className="font-display text-[2.8rem] font-light leading-none mb-1">{d.num}</div>
            <div className="font-mono text-[0.68rem] uppercase tracking-[0.1em] opacity-60">{d.label}</div>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Tools & Technologies */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">04</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Tools & Technologies</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-ink" style={{ border: '1.5px solid hsl(var(--ink))' }}>
        {skills.map((s) => (
          <div key={s.name} className="bg-card-surface p-6 hover-sand transition-colors">
            <div className="text-[1.4rem] mb-3">{s.icon}</div>
            <div className="font-heading font-bold text-[0.82rem] mb-1">{s.name}</div>
            <div className="font-mono text-[0.68rem] text-muted-brand leading-[1.7]">{s.detail}</div>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Expected Outcomes */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">05</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Expected Outcomes</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {outcomes.map((o, i) => (
          <div key={i} className="relative overflow-hidden p-7 hover:-translate-y-1 transition-transform" style={{ border: '1.5px solid hsl(var(--ink))' }}>
            <div className={`absolute top-0 left-0 w-1 h-full ${i === 0 ? 'bg-rust' : i === 1 ? 'bg-teal' : i === 2 ? 'bg-gold' : 'bg-ink'}`} />
            <div className="font-heading font-bold text-[0.9rem] uppercase tracking-[0.04em] mb-3">{o.title}</div>
            <div className="font-mono text-[0.78rem] text-muted-brand leading-[1.8]">{o.text}</div>
          </div>
        ))}
      </div>
    </section>

    {/* Footer */}
    <footer className="px-8 md:px-16 py-8 flex flex-wrap justify-between items-center gap-4 mt-8" style={{ borderTop: '1.5px solid hsl(var(--ink))' }}>
      <div className="font-display italic text-[1.1rem]">Shravani — B.Tech Robotics & Automation, Zeal College</div>
      <div className="flex gap-8">
        {[
          { label: "GitHub", href: "https://github.com/ShravaniKolte" },
          { label: "LinkedIn", href: "https://www.linkedin.com/in/shravani-kolte-a5418a381" },
          { label: "Email", href: "mailto:shravanikolte2103@gmail.com" },
          { label: "Phone", href: "tel:9975822421" },
        ].map((l) => (
          <a key={l.label} href={l.href} target="_blank" rel="noopener noreferrer" className="font-mono text-[0.68rem] uppercase tracking-[0.1em] text-muted-brand hover:text-rust transition-colors">{l.label}</a>
        ))}
      </div>
    </footer>
  </div>
);

export default SkillSurvivalProject;
