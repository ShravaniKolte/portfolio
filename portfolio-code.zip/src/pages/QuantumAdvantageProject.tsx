import { Link } from "react-router-dom";

const phases = [
  { num: "01", name: "Literature Review", desc: "Reviewed 5 papers, identified 3 research gaps in current quantum advantage forecasting literature.", status: "done" },
  { num: "02", name: "Data Collection", desc: "IBM roadmap, McKinsey QT Monitor 2024, NQM docs, and 100K NISQ circuit records.", status: "done" },
  { num: "03", name: "Analysis & Modeling", desc: "ARIMA forecasting, NISQ benchmarking, and India readiness scoring across five dimensions.", status: "done" },
  { num: "04", name: "Paper Writing", desc: "IEEE format research paper with 6 sections, 4 tables, and 4 original charts.", status: "done" },
  { num: "05", name: "Presentation", desc: "🏆 Won — Avishkar '26 Paper Presentation Competition.", status: "done" },
];

const keyResults = [
  { metric: "2026–2028", label: "Quantum Advantage Timeline", desc: "ARIMA model projects practical quantum advantage achievable globally between 2026 and 2028.", bar: "bg-rust", text: "text-rust" },
  { metric: "−0.926", label: "Fidelity Correlation", desc: "Strong inverse correlation between qubit count and fidelity — proves error correction is the critical bottleneck.", bar: "bg-teal", text: "text-teal" },
  { metric: "150×", label: "India Private Investment Gap", desc: "India has only $2.4M private quantum investment vs China's $359M — most critical gap identified.", bar: "bg-gold", text: "text-gold" },
  { metric: "7", label: "Countries Analyzed", desc: "Comparative analysis of USA, China, EU, Japan, South Korea, Israel and India across investment, patents and hardware.", bar: "bg-ink", text: "text-ink" },
];

const datasetStats = [
  { num: "100,000", label: "Circuit Records" },
  { num: "7", label: "Countries Compared" },
  { num: "8", label: "Years IBM Data" },
  { num: "5", label: "Dimensions India Score" },
];

const tools = [
  { icon: "🐍", name: "Python", detail: "Pandas, NumPy, Statsmodels for ARIMA modeling and NISQ data analysis" },
  { icon: "📊", name: "Power BI", detail: "Interactive dashboard for global quantum investment and patent comparison" },
  { icon: "📈", name: "ARIMA", detail: "Time-series forecasting model for IBM qubit scaling projection through 2033" },
  { icon: "📄", name: "IEEE Format", detail: "Full research paper in IEEE two-column format with 4 tables and 4 original charts" },
];

const countryRows = [
  { country: "USA", publicInv: "$1.3B", patentShare: "28%", privateInv: "$3.7B", gap: "1,541×" },
  { country: "China", publicInv: "$15B", patentShare: "37%", privateInv: "$359M", gap: "150×" },
  { country: "EU", publicInv: "$1.2B", patentShare: "16%", privateInv: "$680M", gap: "283×" },
  { country: "Japan", publicInv: "$700M", patentShare: "8%", privateInv: "$120M", gap: "50×" },
  { country: "South Korea", publicInv: "$2.35B", patentShare: "5%", privateInv: "$95M", gap: "40×" },
  { country: "Israel", publicInv: "$385M", patentShare: "3%", privateInv: "$165M", gap: "69×" },
  { country: "India", publicInv: "$735M", patentShare: "2%", privateInv: "$2.4M", gap: "—", highlight: true },
];

const outcomes = [
  { title: "ARIMA Forecast", text: "Projected IBM qubit scaling from 2025 to 2033 with quantum advantage window identified at 2026–2028." },
  { title: "NISQ Analysis", text: "Fidelity drops from 71.8% at 5 qubits to 1% at 15 qubits across 100,000 circuit records." },
  { title: "India Readiness Score", text: "Five-dimension assessment: investment, qubits, patents, companies, and private funding." },
  { title: "IEEE Research Paper", text: "Full paper with 6 sections, 11 references, 4 charts, 4 data tables — Won Avishkar '26." },
];

const tags = [
  { label: "Quantum Computing", color: "text-rust" },
  { label: "Data Analytics", color: "text-teal" },
  { label: "ARIMA", color: "text-gold" },
  { label: "IEEE Paper", color: "text-ink" },
  { label: "Python", color: "text-rust" },
  { label: "Power BI", color: "text-teal" },
];

const QuantumAdvantageProject = () => (
  <div className="min-h-screen">
    {/* Header */}
    <header className="px-8 md:px-16 pt-10 pb-6 flex justify-between items-start animate-fade-down" style={{ borderBottom: '1.5px solid hsl(var(--ink))' }}>
      <Link to="/" className="font-heading text-[1.05rem] font-[800] uppercase tracking-[0.02em] text-ink">
        Shravani<span className="text-rust">.</span>Portfolio
      </Link>
      <nav className="hidden md:flex gap-8 items-center">
        <Link to="/" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Home</Link>
        <Link to="/#projects" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Projects</Link>
        <Link to="/#achievements" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Achievements</Link>
        <Link to="/#skills" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Skills</Link>
        <Link to="/#certifications" className="font-mono text-[0.75rem] uppercase tracking-[0.08em] text-muted-brand hover:text-rust transition-colors">Contact</Link>
      </nav>
    </header>

    {/* Hero */}
    <section className="px-8 md:px-16 py-12 md:py-20 grid grid-cols-1 md:grid-cols-[1fr_380px] gap-8 md:gap-16 items-start animate-fade-up">
      <div>
        <div className="flex items-center gap-2.5 mb-5">
          <span className="inline-block w-6 h-[1.5px] bg-rust" />
          <span className="font-mono text-[0.68rem] uppercase tracking-[0.18em] text-rust">Quantum Computing · Data Analytics · IEEE · 2026</span>
        </div>
        <h1 className="font-display font-medium leading-[1.1] tracking-[-0.02em] mb-7" style={{ fontSize: 'clamp(2.2rem, 4.6vw, 3.6rem)' }}>
          Forecasting<br /><em className="italic text-teal">Quantum Advantage</em><br />in Global Trends &<br />India's Readiness
        </h1>
        <p className="font-mono text-[0.88rem] text-muted-brand leading-[1.9] max-w-[560px] mb-10">
          A data-driven research paper analyzing global quantum computing trends using IBM qubit progression data, 100,000 NISQ circuit records, and country-wise investment comparison. Applies ARIMA forecasting to predict quantum advantage timelines and assesses India's readiness under the National Quantum Mission.
        </p>
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t.label} className={`font-mono text-[0.68rem] uppercase tracking-[0.1em] px-3.5 py-1 ${t.color}`} style={{ border: '1px solid currentColor', borderRadius: '2px' }}>
              {t.label}
            </span>
          ))}
        </div>
      </div>
      <div className="md:border-l md:border-ink md:pl-8 border-t md:border-t-0 border-ink pt-6 md:pt-2 flex flex-col gap-7" style={{ borderWidth: '1.5px' }}>
        {[
          { label: "Project Type", value: "Research · IEEE Paper" },
          { label: "Duration", value: "2026" },
          { label: "Data Period", value: "2016 – 2033" },
          { label: "Role", value: "Co-Researcher (with Manodnya Manoj Pawar)" },
        ].map((m) => (
          <div key={m.label}>
            <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-muted-brand mb-1">{m.label}</div>
            <div className="font-heading font-semibold text-[0.88rem]">{m.value}</div>
          </div>
        ))}
        <div>
          <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-muted-brand mb-1">Status</div>
          <div className="inline-flex items-center gap-1.5 font-mono text-[0.72rem]">
            <span className="w-[7px] h-[7px] rounded-full bg-gold" />
            🏆 Won — Avishkar '26
          </div>
        </div>
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 01 — Research Phases */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">01</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Research Phases</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5" style={{ border: '1.5px solid hsl(var(--ink))' }}>
        {phases.map((p, i) => (
          <div key={i} className="p-6 hover-sand transition-colors relative" style={{ borderRight: i < 4 ? '1.5px solid hsl(var(--ink))' : 'none' }}>
            <div className={`font-display text-[2.5rem] font-light leading-none mb-3 ${i === 4 ? 'text-gold/60' : 'text-teal/35'}`}>
              {p.num}
            </div>
            <div className="font-heading font-bold text-[0.78rem] uppercase tracking-[0.05em] mb-2">{p.name}</div>
            <div className="font-mono text-[0.72rem] text-muted-brand leading-relaxed">{p.desc}</div>
            <span className={`mt-4 inline-block font-mono text-[0.6rem] uppercase tracking-[0.12em] px-2.5 py-1 rounded-sm ${
              i === 4 ? 'bg-gold text-ink' : 'bg-teal text-cream'
            }`}>
              {i === 4 ? '🏆 Won' : '✓ Complete'}
            </span>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 02 — Key Results */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">02</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Key Results</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {keyResults.map((r, i) => (
          <div key={i} className="relative overflow-hidden p-7 hover:-translate-y-1 transition-transform bg-card-surface" style={{ border: '1.5px solid hsl(var(--ink))' }}>
            <div className={`absolute top-0 left-0 w-1 h-full ${r.bar}`} />
            <div className={`font-display text-[2.6rem] font-light leading-none mb-3 ${r.text}`}>{r.metric}</div>
            <div className="font-heading font-bold text-[0.78rem] uppercase tracking-[0.08em] mb-3">{r.label}</div>
            <div className="font-mono text-[0.78rem] text-muted-brand leading-[1.8]">{r.desc}</div>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 03 — Dataset Overview */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">03</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Dataset Overview</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-4 bg-ink text-cream p-6" style={{ border: '1.5px solid hsl(var(--ink))' }}>
          <div className="font-heading font-[800] text-[1rem] mb-2">NISQ-FaultLogs-100K.csv + IBM Quantum Roadmap + McKinsey QT Monitor 2024 + NQM Policy Docs</div>
          <div className="font-mono text-[0.75rem] opacity-70">Multi-source dataset combining empirical NISQ benchmarks, IBM hardware roadmap, global investment data, and Indian National Quantum Mission policy documents.</div>
        </div>
        {datasetStats.map((d) => (
          <div key={d.label} className="bg-card-surface p-6" style={{ border: '1.5px solid hsl(var(--ink))' }}>
            <div className="font-display text-[2.4rem] font-light leading-none mb-1">{d.num}</div>
            <div className="font-mono text-[0.65rem] uppercase tracking-[0.1em] opacity-60">{d.label}</div>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 04 — Tools */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">04</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Tools & Technologies</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-ink" style={{ border: '1.5px solid hsl(var(--ink))' }}>
        {tools.map((s) => (
          <div key={s.name} className="bg-card-surface p-6 hover-sand transition-colors">
            <div className="text-[1.4rem] mb-3">{s.icon}</div>
            <div className="font-heading font-bold text-[0.82rem] mb-1">{s.name}</div>
            <div className="font-mono text-[0.68rem] text-muted-brand leading-[1.7]">{s.detail}</div>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 05 — Country Comparison */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">05</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Country Comparison</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[0.78rem] border-collapse">
          <thead>
            <tr>
              {["Country", "Public Investment", "Patent Share", "Private Investment", "Gap vs India"].map((h) => (
                <th key={h} className="font-heading font-bold text-[0.68rem] uppercase tracking-[0.1em] text-left px-5 py-3.5 bg-ink text-cream">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {countryRows.map((r) => (
              <tr key={r.country} className={`hover-sand transition-colors ${r.highlight ? 'bg-gold/20' : ''}`}>
                <td className="px-5 py-3.5 border-b border-sand font-mono font-bold">{r.country}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.publicInv}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.patentShare}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.privateInv}</td>
                <td className="px-5 py-3.5 border-b border-sand font-mono">{r.gap}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 06 — Research Outcomes */}
    <section className="px-8 md:px-16 py-14">
      <div className="flex items-baseline gap-4 mb-10">
        <span className="font-mono text-[0.65rem] text-rust tracking-[0.1em]">06</span>
        <span className="font-heading font-bold text-[1.1rem] uppercase tracking-[0.04em]">Research Outcomes</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {outcomes.map((o, i) => (
          <div key={i} className="relative overflow-hidden p-7 hover:-translate-y-1 transition-transform" style={{ border: '1.5px solid hsl(var(--ink))' }}>
            <div className={`absolute top-0 left-0 w-1 h-full ${i === 0 ? 'bg-rust' : i === 1 ? 'bg-teal' : i === 2 ? 'bg-gold' : 'bg-ink'}`} />
            <div className="font-heading font-bold text-[0.9rem] uppercase tracking-[0.04em] mb-3">{o.title}</div>
            <div className="font-mono text-[0.78rem] text-muted-brand leading-[1.8]">{o.text}</div>
          </div>
        ))}
      </div>
    </section>

    <div className="section-divider" />

    {/* Section 07 — Read Paper */}
    <section className="px-8 md:px-16 py-20 text-center" style={{ borderTop: '1.5px solid hsl(var(--ink))', borderBottom: '1.5px solid hsl(var(--ink))' }}>
      <div className="flex items-center justify-center gap-2.5 mb-5">
        <span className="inline-block w-6 h-[1.5px] bg-rust" />
        <span className="font-mono text-[0.68rem] uppercase tracking-[0.18em] text-rust">07 · Full Paper</span>
        <span className="inline-block w-6 h-[1.5px] bg-rust" />
      </div>
      <h2 className="font-display font-medium leading-[1.1] tracking-[-0.02em] mb-10" style={{ fontSize: 'clamp(2rem, 4vw, 3.2rem)' }}>
        Read the <em className="italic text-teal">Full Research Paper</em>
      </h2>
      <p className="font-mono text-[0.85rem] text-muted-brand max-w-[560px] mx-auto mb-10 leading-[1.9]">
        Full IEEE-format paper with 6 sections, 11 references, 4 original charts and 4 data tables — winner of Avishkar '26 Paper Presentation Competition.
      </p>
      <div className="flex flex-wrap justify-center gap-4">
        <a
          href="/papers/Forecasting-Quantum-Advantage.pdf"
          target="_blank"
          rel="noopener noreferrer"
          download
          className="font-mono text-[0.75rem] uppercase tracking-[0.12em] px-7 py-4 bg-teal text-cream hover:opacity-90 transition-opacity"
          style={{ border: '1.5px solid hsl(var(--teal))' }}
        >
          ↓ Download Paper
        </a>
        <a
          href="https://github.com/ShravaniKolte"
          target="_blank"
          rel="noopener noreferrer"
          className="font-mono text-[0.75rem] uppercase tracking-[0.12em] px-7 py-4 bg-rust text-cream hover:opacity-90 transition-opacity"
          style={{ border: '1.5px solid hsl(var(--rust))' }}
        >
          → View on GitHub
        </a>
      </div>
    </section>

    {/* Footer */}
    <footer className="px-8 md:px-16 py-8 flex flex-wrap justify-between items-center gap-4 mt-8" style={{ borderTop: '1.5px solid hsl(var(--ink))' }}>
      <div className="font-display italic text-[1.1rem]">Shravani — B.Tech Robotics & Automation, Zeal College</div>
      <div className="flex gap-8">
        {[
          { label: "GitHub", href: "https://github.com/ShravaniKolte" },
          { label: "LinkedIn", href: "https://www.linkedin.com/in/shravani-kolte-a5418a381" },
          { label: "Email", href: "mailto:shravanikolte2103@gmail.com" },
          { label: "Phone", href: "tel:9975822421" },
        ].map((l) => (
          <a key={l.label} href={l.href} target="_blank" rel="noopener noreferrer" className="font-mono text-[0.68rem] uppercase tracking-[0.1em] text-muted-brand hover:text-rust transition-colors">{l.label}</a>
        ))}
      </div>
    </footer>
  </div>
);

export default QuantumAdvantageProject;
